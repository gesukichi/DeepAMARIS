import azure.functions as func

# v1 programming model to match function.json
def main(req: func.HttpRequest) -> func.HttpResponse:
    return func.HttpResponse("ok", status_code=200, mimetype="text/plain")
